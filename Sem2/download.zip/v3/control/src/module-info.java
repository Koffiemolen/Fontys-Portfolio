module control {
    requires java.desktop;

    exports devices;
}