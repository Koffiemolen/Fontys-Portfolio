package nl.StijveHark.Game;

import java.awt.*;

//   Interface for all the objects that will be 'drawn' on the board
public interface Drawable {

    void draw(Graphics graphic);
}
