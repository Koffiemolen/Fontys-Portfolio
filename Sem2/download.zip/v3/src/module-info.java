module SpaceInvaders.Code {

    requires control;
    requires java.desktop;
    requires audio;
    requires dataaccess;
}