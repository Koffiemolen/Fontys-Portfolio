package logic.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AlienTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void draw() {
    }

    @Test
    void getBounds() {
    }

    @Test
    void move() {
    }

    @Test
    void getAlienType() {
    }

    @Test
    void getAlienWidth() {
    }

    @Test
    void getAlienHeight() {
    }
}