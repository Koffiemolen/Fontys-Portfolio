module audio {
    requires java.desktop;

    exports sound;
}