package nl.StijveHark.Game;

// Interface for the movable objects like ship, alien, laser and bomb
public interface Moveable {

    void move();
}
