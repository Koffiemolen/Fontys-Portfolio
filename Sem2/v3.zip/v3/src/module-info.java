module v3 {

    requires control;
    requires java.desktop;
    requires audio;
}